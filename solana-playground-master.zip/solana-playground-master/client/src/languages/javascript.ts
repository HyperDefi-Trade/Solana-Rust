import { PgLanguage } from "../utils/pg";

export const javascript = PgLanguage.create({
  name: "JavaScript",
  extension: "js",
});
