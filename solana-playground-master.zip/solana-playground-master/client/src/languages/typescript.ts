import { PgLanguage } from "../utils/pg";

export const typescript = PgLanguage.create({
  name: "TypeScript",
  extension: "ts",
});
