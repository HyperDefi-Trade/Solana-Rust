import { PgLanguage } from "../utils/pg";

export const python = PgLanguage.create({
  name: "Python",
  extension: "py",
});
