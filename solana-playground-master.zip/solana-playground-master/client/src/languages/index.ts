import * as _LANGUAGES from "./languages";

/** All programming languages */
export const LANGUAGES = Object.values(_LANGUAGES);
