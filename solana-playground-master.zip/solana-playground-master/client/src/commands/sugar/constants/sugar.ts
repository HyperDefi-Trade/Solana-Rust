export const VALID_CATEGORIES = ["image", "video", "audio", "vr", "html"];
