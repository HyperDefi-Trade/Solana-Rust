export enum BundlrEnpoints {
  DEVNET = "https://devnet.bundlr.network",
  MAINNET = "https://node1.bundlr.network",
}
