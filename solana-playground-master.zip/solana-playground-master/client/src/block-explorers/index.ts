import * as _BLOCK_EXPLORERS from "./block-explorers";

export const BLOCK_EXPLORERS = Object.values(_BLOCK_EXPLORERS);
