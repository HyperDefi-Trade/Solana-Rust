import { createThemes } from "./create";

/** All available themes */
export const THEMES = createThemes("Dracula", "Solana", "Playground", "Light");
