export { default } from "./Img";
