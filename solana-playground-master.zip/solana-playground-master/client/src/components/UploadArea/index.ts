export { default } from "./UploadArea";
