export { default } from "./LangIcon";
