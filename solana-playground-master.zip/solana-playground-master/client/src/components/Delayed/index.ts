export { default } from "./Delayed";
