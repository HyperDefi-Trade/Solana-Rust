export { default } from "./Resizable";
