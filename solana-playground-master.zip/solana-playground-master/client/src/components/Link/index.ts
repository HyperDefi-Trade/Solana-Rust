export { default } from "./Link";
export type { LinkProps } from "./Link";
