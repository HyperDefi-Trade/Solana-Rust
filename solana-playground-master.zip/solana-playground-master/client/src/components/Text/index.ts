export { default } from "./Text";
export type { TextKind } from "./Text";
