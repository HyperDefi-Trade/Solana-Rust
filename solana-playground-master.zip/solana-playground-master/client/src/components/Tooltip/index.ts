export { default } from "./Tooltip";
export type { TooltipProps } from "./Tooltip";
