export { default } from "./Terminal";
