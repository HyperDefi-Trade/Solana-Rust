import { initRustAnalyzer } from "./rust-analyzer";

export const init = () => initRustAnalyzer();
