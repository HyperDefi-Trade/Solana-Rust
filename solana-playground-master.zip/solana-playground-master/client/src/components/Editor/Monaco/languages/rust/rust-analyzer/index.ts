export { initRustAnalyzer } from "./rust-analyzer";
