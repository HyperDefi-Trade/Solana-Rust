export { automaticAirdrop } from "./automatic-airdrop";
