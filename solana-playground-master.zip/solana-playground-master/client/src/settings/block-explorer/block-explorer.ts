import { createSetting } from "../create";

export const blockExplorer = createSetting({
  name: "Block explorer",
  tooltip: {
    element: "Default block explorer to use",
  },
});
