import { createSetting } from "../create";

export const font = createSetting({
  name: "Font",
});
