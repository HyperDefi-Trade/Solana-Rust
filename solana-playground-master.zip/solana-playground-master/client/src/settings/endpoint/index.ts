export { endpoint } from "./endpoint";
