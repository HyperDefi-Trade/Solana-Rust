## What you will learn

- How to build and deploy an Anchor program
- How to interact with your on chain program using TypeScript
- How to fetch on-chain transaction information
