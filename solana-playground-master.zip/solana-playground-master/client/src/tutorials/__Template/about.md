## What you will learn

- How to get started with Solana Playground
- How to create a Solana wallet on Playground
- How to program a basic Solana program in Rust
- How to build and deploy a Solana Rust program
- How to interact with your on chain program using JavaScript
