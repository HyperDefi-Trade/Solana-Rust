export { default } from "./HelloSolana";
