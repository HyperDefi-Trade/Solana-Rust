## What you will learn

- How to build and deploy a Solana Rust program
- How to interact with your on chain program using TypeScript
- How to fetch on-chain transaction information
