declare module '*.md' {
  const content: string;
  export = content;
}