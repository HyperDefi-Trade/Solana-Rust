export const PROJECT_NAME = "Solana Playground";

export const GITHUB_URL =
  "https://github.com/solana-playground/solana-playground";
