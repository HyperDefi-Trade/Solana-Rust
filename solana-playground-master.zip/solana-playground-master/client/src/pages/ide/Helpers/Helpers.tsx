import { useHelpConnection } from "./connection";

const Helpers = () => {
  useHelpConnection();

  return null;
};

export default Helpers;
