- Run the following command in your terminal:

```sh
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"
```
