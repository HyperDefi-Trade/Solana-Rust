export { default } from "./Panels";
