export { default } from "./Right";
