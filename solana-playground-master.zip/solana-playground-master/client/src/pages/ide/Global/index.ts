export { default } from "./Global";
